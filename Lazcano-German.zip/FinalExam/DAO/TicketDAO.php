<?php namespace DAO;

use Models\Ticket;

class TicketDAO{
    private $connection;

    public function getAll(){
        try {
            $query = 'select * from tickets;';
            $this->connection = Connection::GetInstance();
            $result = $this->connection->Execute($query);
            $result = array_map(function($ticket){
                return new Ticket($ticket['ticketTypeId'], $ticket['name'], $ticket['email'], $ticket['description'], $ticket['date'], $ticket['ticketId']);
            }, $result);
            return $result;
        } catch (Throwable $th) {
            throw $th;
        }
    }

    public function add($ticketTypeId, $date, $name, $email, $description){
        try {
            $query = "insert into tickets (ticketTypeId, name, email, description, date) values (:ticketTypeId, :name, :email, :description, :date);";
            $this->connection = Connection::GetInstance();
            $parameters['ticketTypeId'] = $ticketTypeId;
            $parameters['name'] = $name;
            $parameters['email'] = $email;
            $parameters['description'] = $description;
            $parameters['date'] = $date;
            $this->connection->ExecuteNonQuery($query, $parameters);
        } catch (Throwable $th) {
            throw $th;
        }
    }
}