CREATE DATABASE IF NOT EXISTS Tickets;

USE Tickets;

CREATE TABLE IF NOT EXISTS tickets
(
    ticketId INT NOT NULL AUTO_INCREMENT,
    ticketTypeId INT NOT NULL,
    name NVARCHAR(100) NOT NULL,
    email NVARCHAR(100) NOT NULL,
    description NVARCHAR(1000) NOT NULL,
    CONSTRAINT PK_Tickets PRIMARY KEY (ticketId)  
)Engine=InnoDB;

CREATE TABLE IF NOT EXISTS tickettypes
(
    ticketTypeId INT NOT NULL AUTO_INCREMENT,
    description NVARCHAR(100) NOT NULL,
    CONSTRAINT PK_TicketTypes PRIMARY KEY (ticketTypeId)
)Engine=InnoDB;

CREATE TABLE IF NOT EXISTS users
(
    userId INT NOT NULL AUTO_INCREMENT,
    email NVARCHAR(100) NOT NULL,
    password NVARCHAR(100) NOT NULL,
    CONSTRAINT PK_Users PRIMARY KEY (userId)
)Engine=InnoDB;

INSERT INTO users
	(email, password)
VALUES 
	('user@myapp.com', '123456');

INSERT INTO tickettypes
	(description)
VALUES 
	('New User Request'),
    ('Password Reset'),
    ('Remove User'),
    ('Modify User Details');