<?php
    require_once('nav.php');
?>
<main class="py-5">
     <section id="listado" class="mb-5">
          <div class="container">
               <h2 class="mb-4">Listado de Tickets</h2>
               <table class="table bg-light-alpha">
                    <thead>                         
                         <th>Tipo</th>
                         <th>Fecha</th>
                         <th>Nombre</th>
                         <th>Email</th>
                         <th>Acción</th>
                    </thead>
                    <tbody>
                    <?php foreach($ticketsList as $ticket){ ?>
                         <tr>                             
                              <td><?= $ticket->getTicketid() ?></td>
                              <td><?= $ticket->getDate() ?></td>
                              <td><?= $ticket->getName() ?></td>
                              <td><?= $ticket->getEmail() ?></td>
                              <td><a href="#" class="btn btn-danger" role="button" aria-pressed="true">Eliminar</a></td>
                         </tr>
                    <?php } ?>                        
                        
                    </tbody>
               </table>
          </div>
     </section>
</main>