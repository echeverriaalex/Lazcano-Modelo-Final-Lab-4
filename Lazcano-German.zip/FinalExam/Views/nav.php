<nav class="navbar navbar-expand-lg  navbar-dark bg-dark">
     <span class="navbar-text">
          <strong>LabIV - Final</strong>
     </span>
     <ul class="navbar-nav ml-auto">
          <li class="nav-item">
               <a class="nav-link" href="<?=FRONT_ROOT?>Tickets/Add">Agregar Ticket</a>
          </li>
          <li class="nav-item">
               <a class="nav-link" href="<?=FRONT_ROOT?>Tickets/List">Listar Tickets</a>
          </li>   
          <li class="nav-item">
               <a class="nav-link" href="<?=FRONT_ROOT?>Users/logout">Cerrar Sesión</a>
          </li>        
     </ul>
</nav>