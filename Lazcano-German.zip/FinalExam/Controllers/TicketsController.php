<?php namespace Controllers;

use DAO\TicketDAO;
use DAO\TicketTypeDAO;

class TicketsController{
    private $ticketDAO;
    private $ticketTypeDAO;

    public function __construct(){
        $this->ticketDAO = new TicketDAO;
        $this->ticketTypeDAO = new TicketTypeDAO;
    }

    public function list(){
        if(isset($_SESSION['email'])){
            $ticketsList = $this->ticketDAO->getAll();
            require_once(VIEWS_PATH.'ticket-list.php');
        }else{
            header("location:".FRONT_ROOT."index.php");
        }
    } 

    public function add($ticketTypeId = null, $date = null, $name = null, $email = null, $description = null){
        if(isset($_SESSION['email'])){
            $ticketsTypeList = $this->ticketTypeDAO->getAll();

            if($ticketTypeId != null && $date != null && $name != null && $email != null && $description != null){
                $ticketsList = $this->ticketDAO->getAll();

                foreach ($ticketsList as $ticket) {
                    if($ticket->getTickettypeid() != $ticketTypeId && $ticket->getEmail() != $email && $ticket->getDate() != $date){
                        $this->ticketDAO->add($ticketTypeId, $date, $name, $email, $description);
                        require_once(VIEWS_PATH.'ticket-add.php');
                    }else{
                        print('No se pudo agregar');
                        require_once(VIEWS_PATH.'ticket-add.php');
                    }
                }

            }else{
                print('ENTRA siempre ACA, no llegue a arreglarlo');
                require_once(VIEWS_PATH.'ticket-add.php');
            }
        }else{
            header("location:".FRONT_ROOT."index.php");
        }
    }
}